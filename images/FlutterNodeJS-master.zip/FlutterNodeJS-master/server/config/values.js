const values = {
    saltRounds: 10,
    authErrorString: 'WRONG_EMAIL_OR_PASSWORD',
    maxEventListeners: 75,
    limitRun: 50
};

module.exports = values;