const Film = require('./../models/Film');
const User = require('./../models/User');

module.exports= {
    Film,
    User
};