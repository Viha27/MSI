package com.auth0.flutterdemo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
